/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package guessinggame;
import java.awt.Image;
/**
 *
 * @author rdb115
 */
public class Card{
    public int suit, value;
    private String[] cardSuit = {"Spades", "Diamonds", "Hearts", "Clubs"};
    private String[] cardValue ={"Ace", "King", "Queen", "Jack", "10", "9", "8", "7", "6", "5", "4", "3", "2"};
    
    public void card(int cSuit, int cValue){
        suit = cSuit;
        value = cValue;
    }
    public String toString(){
        String cardInfo = cardValue[value] + "of" + cardSuit[suit];
        return cardInfo;
    }
    public int getValue(){
        return value + 1;
    }
    
    public String getImage(){
        String path = cardValue[value] + cardSuit[suit];
        return path;
    }
}
