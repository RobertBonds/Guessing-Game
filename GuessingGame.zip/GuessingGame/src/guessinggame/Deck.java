/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package guessinggame;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author rdb115
 */
public class Deck{
    List<Card> deck = new ArrayList<Card>();
    
    
    
public void addToDeck(){    
    for(int i = 0; i < 52; i++){
        Card c = new Card();
        c.suit = i % 4;
        c.value = i % 13;
        deck.add(c);
    }
}

public void shuffle(){
    Collections.shuffle(deck);
}

public Card dealCard(int i ){
    Card c = deck.get(i);
    //deck.remove(i);
    return c;
    
}

public void addCard(Card c){
    deck.add(c);
}

public int size(){
    return deck.size();
}

public Card get(int i){
    Card c = new Card();
    c = deck.get(i);
    return c;
}
public boolean empty(){
    if(deck.isEmpty())
        return true;
    else
        return false;
}


}
