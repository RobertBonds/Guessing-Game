/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guessinggame;

import java.text.*;
import java.util.*;
import javax.swing.*;

/**
 *
 * @author rd-bondswiu.edu
 */
public class GamePage extends javax.swing.JFrame {

    /**
     * Creates new form GamePage
     */
    Deck d = new Deck();
    List<Card> cardList = new ArrayList();
    Card card1, card2, card3;

    double score = 0;
    int guessValue;
    int guessSuit;
    int round = 1;
    int guessNum = 0;
    int randomCard = 0;
    double finalScore = 0;
    String winningPer;
    int suit = 0;

    String[] iconNames = new String[3]; 

    public GamePage() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cardOneButton = new javax.swing.JButton();
        cardTwoButton = new javax.swing.JButton();
        cardThreeButton = new javax.swing.JButton();
        cardOneLabel = new javax.swing.JLabel();
        cardThreeLabel = new javax.swing.JLabel();
        shuffleAndDealButton = new javax.swing.JButton();
        gameover = new javax.swing.JLabel();
        scorelabel = new javax.swing.JLabel();
        cardTwoLabel = new javax.swing.JLabel();
        cardToGuessLabel = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        roundLabel = new javax.swing.JLabel();
        scoreField = new javax.swing.JTextField();
        scoreLabel = new javax.swing.JLabel();
        finalScoreLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        cardOneButton.setText("Card 1");
        cardOneButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cardOneButtonActionPerformed(evt);
            }
        });

        cardTwoButton.setText("Card 2");
        cardTwoButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cardTwoButtonActionPerformed(evt);
            }
        });

        cardThreeButton.setText("Card 3");
        cardThreeButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cardThreeButtonActionPerformed(evt);
            }
        });

        cardOneLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/b2fv.png"))); // NOI18N

        cardThreeLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/b2fv.png"))); // NOI18N

        shuffleAndDealButton.setText("Shuffle and Deal");
        shuffleAndDealButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                shuffleAndDealButtonActionPerformed(evt);
            }
        });

        cardTwoLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/b2fv.png"))); // NOI18N

        cardToGuessLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/b2fv.png"))); // NOI18N

        jTextField1.setText("Round:");

        roundLabel.setMaximumSize(new java.awt.Dimension(25, 15));
        roundLabel.setMinimumSize(new java.awt.Dimension(2, 2));
        roundLabel.setPreferredSize(new java.awt.Dimension(25, 15));

        scoreField.setText("Score:");

        scoreLabel.setMaximumSize(new java.awt.Dimension(25, 15));
        scoreLabel.setMinimumSize(new java.awt.Dimension(25, 15));
        scoreLabel.setPreferredSize(new java.awt.Dimension(25, 15));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(150, 150, 150)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(shuffleAndDealButton)
                                            .addComponent(gameover, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(scorelabel, javax.swing.GroupLayout.DEFAULT_SIZE, 126, Short.MAX_VALUE)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(174, 174, 174)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(cardTwoLabel)
                                            .addComponent(cardToGuessLabel))))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(0, 45, Short.MAX_VALUE)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(cardOneButton)
                                                    .addComponent(cardOneLabel))
                                                .addGap(187, 187, 187))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(cardTwoButton)
                                                .addGap(74, 74, 74)))
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(cardThreeLabel)
                                            .addComponent(cardThreeButton)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(roundLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(scoreField, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGap(18, 18, 18))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(174, 174, 174)
                        .addComponent(finalScoreLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(scoreLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(shuffleAndDealButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(roundLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(scoreField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(scoreLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(gameover, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scorelabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(finalScoreLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 48, Short.MAX_VALUE)
                .addComponent(cardToGuessLabel)
                .addGap(39, 39, 39)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cardTwoLabel, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(cardOneLabel, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(cardThreeLabel, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(41, 41, 41)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cardOneButton)
                    .addComponent(cardTwoButton)
                    .addComponent(cardThreeButton))
                .addGap(23, 23, 23))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void shuffleAndDealButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_shuffleAndDealButtonActionPerformed
        //Prepares list of cards to choose from
        roundLabel.setText(Integer.toString(round));
        scoreLabel.setText(Double.toString(score));
        d.addToDeck();
        d.shuffle();
        
        //flip cards over at the beginning of rounds
        if(round > 1){
            cardOneLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/b2fv.png")));
            cardTwoLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/b2fv.png")));
            cardThreeLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/b2fv.png")));
            cardToGuessLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/b2fv.png")));
        }
        
        for (int i = 0; i < 3; i++) {
            cardList.add(d.get(i));
        }
        //Select Random card from list for guess
        randomCard = 0 + (int)(Math.random() * ((2 - 0) + 1));
    }//GEN-LAST:event_shuffleAndDealButtonActionPerformed

    private void cardOneButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cardOneButtonActionPerformed
        //After the player selects their card, the correct card is shown and the
       //score and round are adjusted
        
        for (int i = 0; i < cardList.size(); i++) {
            iconNames[i] = "/images/" + cardList.get(i).getImage() + ".png";
        }

        cardOneLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource(iconNames[0])));

        guessNum = cardList.get(randomCard).value;
        guessSuit = cardList.get(randomCard).suit;
        
        cardToGuessLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource(iconNames[randomCard])));
        
        if(cardList.get(0).value == guessNum && cardList.get(0).suit == guessSuit){
            score++;
            round++;
        }
        else{
            round++;
        }
       if(round == 10){
            gameover.setText("Game Over");
            finalScore = (score/round) * 100;
            
            winningPer = Double.toString(finalScore) + "%";
            finalScoreLabel.setText(winningPer);            
       }
        cardList.clear();
    }//GEN-LAST:event_cardOneButtonActionPerformed

    private void cardTwoButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cardTwoButtonActionPerformed
        // TODO add your handling code here:
        //After the player selects their card, the correct card is shown and the
       //score and round are adjusted
        for (int i = 0; i < cardList.size(); i++) {
            iconNames[i] = "/images/" + cardList.get(i).getImage() + ".png";
        }

        cardTwoLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource(iconNames[1])));

        guessNum = cardList.get(randomCard).value;
        guessSuit = cardList.get(randomCard).suit;
        
        cardToGuessLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource(iconNames[randomCard])));
        
        if(cardList.get(1).value == guessNum && cardList.get(1).suit == guessSuit){
            score++;
            round++;
        }
        else{
            round++;
        }
        
         if(round == 10){
            gameover.setText("Game Over");
            finalScore = (score/round) * 100;
            
            winningPer = Double.toString(finalScore) + "%";
            finalScoreLabel.setText(winningPer);
       }
        cardList.clear();
    }//GEN-LAST:event_cardTwoButtonActionPerformed

    private void cardThreeButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cardThreeButtonActionPerformed
        //After the player selects their card, the correct card is shown and the
       //score and round are adjusted
        
        for (int i = 0; i < cardList.size(); i++) {
            iconNames[i] = "/images/" + cardList.get(i).getImage() + ".png";
        }

        cardThreeLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource(iconNames[2])));

        guessNum = cardList.get(randomCard).value;
        guessSuit = cardList.get(randomCard).suit;
        
        cardToGuessLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource(iconNames[randomCard])));

        if(cardList.get(2).value == guessNum && cardList.get(2).suit == guessSuit){
            score++;
            round++;
        }
        else{
            round++;
        }
         if(round == 10){
            gameover.setText("Game Over");
            finalScore = (score/round) * 100;
            
            winningPer = Double.toString(finalScore) + "%";
            finalScoreLabel.setText(winningPer);
       }
        cardList.clear();
    }//GEN-LAST:event_cardThreeButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GamePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GamePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GamePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GamePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GamePage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cardOneButton;
    private javax.swing.JLabel cardOneLabel;
    private javax.swing.JButton cardThreeButton;
    private javax.swing.JLabel cardThreeLabel;
    private javax.swing.JLabel cardToGuessLabel;
    private javax.swing.JButton cardTwoButton;
    private javax.swing.JLabel cardTwoLabel;
    private javax.swing.JLabel finalScoreLabel;
    private javax.swing.JLabel gameover;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JLabel roundLabel;
    private javax.swing.JTextField scoreField;
    private javax.swing.JLabel scoreLabel;
    private javax.swing.JLabel scorelabel;
    private javax.swing.JButton shuffleAndDealButton;
    // End of variables declaration//GEN-END:variables
}
